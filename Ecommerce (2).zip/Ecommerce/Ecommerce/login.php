<?php
session_start(); // Start the session
include 'includes/db.php';
include 'includes/roles_init.php';

// Handle login form submission
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Validation
    if (empty($email) || empty($password)) {
        $login_error = "Email and password are required.";
    } elseif (strlen($password) < 6) {
        $login_error = "Password must be at least 6 characters long.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $login_error = "Please enter a valid email address.";
    } else {
        // Fetch user from the database
        $email_escaped = $conn->real_escape_string($email);
        $sql = "SELECT * FROM users WHERE email = '$email_escaped'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = isset($user['role']) ? $user['role'] : 'user';
                // Redirect admins to admin dashboard
                if ($_SESSION['role'] === 'admin') {
                    header("Location: admin/index.php");
                } else {
                    header("Location: index.php");
                }
                exit();
            } else {
                $login_error = "Invalid email or password.";
            }
        } else {
            $login_error = "No account found with that email address.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="auth-container">
        <div class="text-center mb-4">
            <h2 class="auth-title">Welcome Back!</h2>
            <p class="text-muted mb-3"><i class="fas fa-cookie-bite"></i> Sign in to Swadist</p>
        </div>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <?php if (!empty($login_error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle"></i> <?php echo $login_error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        <form action="login.php" method="POST" novalidate>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                                <small class="form-text text-muted">We'll never share your email.</small>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" minlength="6" required>
                                <small class="form-text text-muted">Minimum 6 characters.</small>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 fw-bold"><i class="fas fa-sign-in-alt"></i> Login</button>
                        </form>
                        <div class="auth-link">
                            Don't have an account? <a href="signup.php">Sign Up Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>