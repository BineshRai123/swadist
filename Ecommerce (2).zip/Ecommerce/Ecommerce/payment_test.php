<?php
session_start();
include 'includes/db.php';

// Handle test payment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = $_POST['order_id'];
    $amount = $_POST['amount'];
    $user_id = $_SESSION['user_id'];

    // Simulate payment processing
    $transaction_code = 'TEST_' . uniqid();
    
    // Update order status to completed
    $sql = "UPDATE orders SET status = 'completed' WHERE id = $order_id AND user_id = $user_id";
    if ($conn->query($sql)) {
        // Clear session data
        unset($_SESSION['cart']);
        unset($_SESSION['pending_order_id']);
        unset($_SESSION['transaction_uuid']);
        unset($_SESSION['payment_amount']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - Mithila Snacks Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-success">
                    <div class="card-body text-center">
                        <div style="font-size: 48px; color: #28a745; margin-bottom: 20px;">✓</div>
                        <h2 class="text-success mb-3">Payment Successful!</h2>
                        <p class="lead">Thank you for your purchase.</p>
                        
                        <div class="alert alert-info">
                            <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order_id); ?></p>
                            <p><strong>Transaction Code:</strong> <?php echo htmlspecialchars($transaction_code); ?></p>
                            <p><strong>Amount:</strong> Rs. <?php echo htmlspecialchars($amount); ?></p>
                            <p><strong>Status:</strong> <span class="badge bg-success">Completed</span></p>
                            <p class="small text-muted mt-2">(Test Payment)</p>
                        </div>

                        <p class="text-muted">Your order has been confirmed and will be processed shortly.</p>
                        
                        <div class="mt-4">
                            <a href="orders.php" class="btn btn-primary">View Orders</a>
                            <a href="index.php" class="btn btn-outline-primary">Continue Shopping</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
    } else {
        header("Location: orders.php?message=error");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}
?>
