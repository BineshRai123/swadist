<?php 
session_start();
include 'includes/db.php';

// Check if user is logged in
$is_logged_in = isset($_SESSION['user_id']);
$user_id = $is_logged_in ? $_SESSION['user_id'] : null;

// Handle adding item to wishlist
if (isset($_GET['product_id']) && $is_logged_in) {
    $product_id = intval($_GET['product_id']);
    
    // Check if product already in wishlist
    $sql = "SELECT id FROM wishlist WHERE user_id = $user_id AND product_id = $product_id";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 0) {
        // Add to wishlist
        $sql = "INSERT INTO wishlist (user_id, product_id) VALUES ($user_id, $product_id)";
        $conn->query($sql);
    }
    
    header("Location: wishlist.php");
    exit();
}

// Handle removing item from wishlist
if (isset($_GET['remove_id']) && $is_logged_in) {
    $wishlist_id = intval($_GET['remove_id']);
    $sql = "DELETE FROM wishlist WHERE id = $wishlist_id AND user_id = $user_id";
    $conn->query($sql);
    
    header("Location: wishlist.php");
    exit();
}

// Get wishlist items
$wishlist_items = array();
if ($is_logged_in) {
    $sql = "SELECT w.id as wishlist_id, p.* FROM wishlist w 
            JOIN products p ON w.product_id = p.id 
            WHERE w.user_id = $user_id 
            ORDER BY w.id DESC";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $wishlist_items[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5 mb-5">
        <div class="mb-4">
            <h1 class="mb-3" style="color: var(--primary-color);">
                <i class="fas fa-heart" style="color: #e74c3c;"></i> My Wishlist
            </h1>
        </div>

        <?php if (!$is_logged_in): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle"></i> 
                <strong>Login Required:</strong> Please <a href="login.php" class="alert-link">login to your account</a> to view your wishlist.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php elseif (empty($wishlist_items)): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="fas fa-heart-broken"></i>
                <strong>Your wishlist is empty!</strong> Start adding products to your wishlist.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <div class="text-center mt-4">
                <a href="index.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-shopping-bag"></i> Continue Shopping
                </a>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($wishlist_items as $item): ?>
                    <div class="col-md-4 col-lg-3 mb-4">
                        <div class="card product-card border-0 shadow-sm h-100">
                            <div class="product-card-img-wrapper">
                                <img src="assets/images/<?php echo htmlspecialchars($item['image']); ?>" 
                                     class="card-img-top" 
                                     alt="<?php echo htmlspecialchars($item['name']); ?>">
                                <span class="product-badge">
                                    <i class="fas fa-heart" style="color: #e74c3c;"></i> Wishlist
                                </span>
                            </div>
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?php echo htmlspecialchars($item['name']); ?></h5>
                                <p class="card-text text-muted small">
                                    <?php echo htmlspecialchars(substr($item['description'], 0, 60)) . '...'; ?>
                                </p>
                                <div class="mt-auto">
                                    <p class="product-price">Rs. <?php echo number_format($item['price'], 2); ?></p>
                                    <div class="product-actions">
                                        <form action="add_to_cart.php" method="POST" class="flex-grow-1">
                                            <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="btn btn-cart w-100 btn-sm">
                                                <i class="fas fa-shopping-cart"></i> Add to Cart
                                            </button>
                                        </form>
                                    </div>
                                    <div class="mt-2">
                                        <a href="product.php?id=<?php echo $item['id']; ?>" class="btn btn-view btn-sm w-100">
                                            <i class="fas fa-eye"></i> View Details
                                        </a>
                                    </div>
                                    <div class="mt-2">
                                        <a href="wishlist.php?remove_id=<?php echo $item['wishlist_id']; ?>" 
                                           class="btn btn-danger btn-sm w-100"
                                           onclick="return confirm('Remove from wishlist?')">
                                            <i class="fas fa-trash"></i> Remove
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-4 text-center">
                <a href="index.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Continue Shopping
                </a>
            </div>
        <?php endif; ?>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>