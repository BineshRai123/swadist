<?php
session_start(); // Start the session
include 'includes/db.php';
include 'recommend.php';

$product_id = $_GET['id'];
$sql = "SELECT * FROM products WHERE id = $product_id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Get user ID if logged in
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($row['name']); ?> - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active"><?php echo htmlspecialchars($row['name']); ?></li>
            </ol>
        </nav>
        <div class="row">
            <div class="col-md-5">
                <div class="product-image-wrapper" style="background: #f9f5f0; border-radius: 10px; padding: 1rem;">
                    <img src="assets/images/<?php echo htmlspecialchars($row['image']); ?>" class="img-fluid" alt="<?php echo htmlspecialchars($row['name']); ?>" style="border-radius: 8px;">
                </div>
            </div>
            <div class="col-md-7">
                <div class="product-info">
                    <div class="mb-3">
                        <span class="mithila-badge"><i class="fas fa-leaf"></i> Authentic Mithila</span>
                    </div>
                    <h1 class="mb-2" style="color: var(--primary-color);"><?php echo htmlspecialchars($row['name']); ?></h1>
                    <h2 class="text-danger fw-bold mb-3">Rs. <?php echo number_format($row['price'], 2); ?></h2>
                    <p class="fs-5 text-muted mb-3"><?php echo htmlspecialchars($row['description']); ?></p>
                    
                    <!-- Product Details -->
                    <div class="card mb-4" style="background: #f9f5f0; border: none;">
                        <div class="card-body">
                            <h6 class="card-title fw-bold mb-3"><i class="fas fa-info-circle"></i> About This Product</h6>
                            <ul class="list-unstyled small">
                                <li><i class="fas fa-leaf" style="color: #27ae60;"></i> <strong>Quality:</strong> Premium quality ingredients</li>
                                <li><i class="fas fa-droplet" style="color: #27ae60;"></i> <strong>Freshness:</strong> Recently prepared</li>
                                <li><i class="fas fa-shield" style="color: #27ae60;"></i> <strong>Standards:</strong> Food safety certified</li>
                                <li><i class="fas fa-package" style="color: #27ae60;"></i> <strong>Packaging:</strong> Securely packed</li>
                            </ul>
                        </div>
                    </div>

                    <form action="add_to_cart.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                        <div class="mb-3">
                            <label for="quantity" class="form-label fw-bold">Select Quantity:</label>
                            <input type="number" id="quantity" name="quantity" value="1" min="1" max="100" class="form-control" style="width: 120px;" required>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-danger btn-lg fw-bold flex-grow-1">
                                <i class="fas fa-shopping-cart"></i> Add to Cart
                            </button>
                            <a href="wishlist.php?product_id=<?php echo $row['id']; ?>" class="btn btn-outline-primary btn-lg fw-bold">
                                <i class="fas fa-heart"></i> Add to Wishlist
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Feature Highlights -->
        <div class="row mt-5 mb-4">
            <div class="col-md-3 text-center">
                <div class="mb-2"><i class="fas fa-truck" style="font-size: 2rem; color: var(--primary-color);"></i></div>
                <h6>Fast Delivery</h6>
                <p class="small text-muted">Quick & Safe Shipping</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="mb-2"><i class="fas fa-undo" style="font-size: 2rem; color: var(--primary-color);"></i></div>
                <h6>Easy Returns</h6>
                <p class="small text-muted">30-day Return Policy</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="mb-2"><i class="fas fa-lock" style="font-size: 2rem; color: var(--primary-color);"></i></div>
                <h6>Secure Payment</h6>
                <p class="small text-muted">100% Safe Checkout</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="mb-2"><i class="fas fa-headset" style="font-size: 2rem; color: var(--primary-color);"></i></div>
                <h6>Customer Support</h6>
                <p class="small text-muted">24/7 Help Available</p>
            </div>
        </div>

        <!-- Similar Products Section -->
        <div class="row mt-5">
            <div class="col-12">
                <h3 class="mb-4" style="color: var(--primary-color);"><i class="fas fa-star"></i> You Might Also Like</h3>
                <div class="row">
                    <?php
                    $recommender = new ProductRecommendation($conn, $user_id ? $user_id : 0);
                    $similar_products = $recommender->getRecommendations(3);
                    
                    if (!empty($similar_products)) {
                        foreach ($similar_products as $similar) {
                            echo '
                            <div class="col-md-4 mb-4">
                                <div class="card product-card">
                                    <img src="assets/images/' . $similar['image'] . '" class="card-img-top" alt="' . $similar['name'] . '">
                                    <div class="card-body">
                                        <h5 class="card-title">' . $similar['name'] . '</h5>
                                        <p class="card-text">' . substr($similar['description'], 0, 80) . '...</p>
                                        <p class="card-text"><strong>Rs. ' . $similar['price'] . '</strong></p>
                                        <a href="product.php?id=' . $similar['id'] . '" class="btn btn-outline-primary">View Product</a>
                                    </div>
                                </div>
                            </div>';
                        }
                    } else {
                        echo "<p class='text-muted'>No similar products found.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>