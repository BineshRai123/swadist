<?php
session_start(); // Start the session
include 'includes/db.php';
include 'includes/roles_init.php';

// Handle signup form submission
$signup_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    // Validation
    if (empty($name) || empty($email) || empty($password) || empty($password_confirm)) {
        $signup_error = "All fields are required.";
    } elseif (strlen($name) < 2) {
        $signup_error = "Name must be at least 2 characters long.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $signup_error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $signup_error = "Password must be at least 6 characters long.";
    } elseif ($password !== $password_confirm) {
        $signup_error = "Passwords do not match.";
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $signup_error = "Password must contain at least one uppercase letter and one number.";
    } else {
        // Check if email already exists
        $email_escaped = $conn->real_escape_string($email);
        $check_sql = "SELECT id FROM users WHERE email = '$email_escaped'";
        $check_result = $conn->query($check_sql);

        if ($check_result->num_rows > 0) {
            $signup_error = "This email is already registered. Please <a href='login.php'>login</a> instead.";
        } else {
            $name_escaped = $conn->real_escape_string($name);
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            
            // Insert user into the database
            $sql = "INSERT INTO users (name, email, password) VALUES ('$name_escaped', '$email_escaped', '$password_hash')";
            if ($conn->query($sql)) {
                $_SESSION['user_id'] = $conn->insert_id;
                header("Location: index.php");
                exit();
            } else {
                $signup_error = "Error creating account. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="auth-container">
        <div class="text-center mb-4">
            <h2 class="auth-title">Welcome to SWADIST!</h2>
            <p class="text-muted mb-3"><i class="fas fa-cookie-bite"></i> Join our Mithila snacks community</p>
        </div>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title text-center mb-4">Create Your Account</h5>
                        <?php if (!empty($signup_error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle"></i> <?php echo $signup_error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        <form action="signup.php" method="POST" novalidate>
                            <div class="mb-3">
                                <label for="name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="name" name="name" minlength="2" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                                <small class="form-text text-muted">At least 2 characters.</small>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                                <small class="form-text text-muted">We'll use this to verify your account.</small>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" minlength="6" required>
                                <small class="form-text text-muted">At least 6 characters, 1 uppercase letter, and 1 number.</small>
                            </div>
                            <div class="mb-3">
                                <label for="password_confirm" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="password_confirm" name="password_confirm" minlength="6" required>
                                <small class="form-text text-muted">Must match the password above.</small>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Create Account</button>
                        </form>
                        <p class="text-center mt-3">Already have an account? <a href="login.php">Login</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>