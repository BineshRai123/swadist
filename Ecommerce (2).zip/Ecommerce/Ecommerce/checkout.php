<?php
session_start(); // Start the session
include 'includes/db.php';

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle order placement - redirect to payment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header("Location: payment.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - E-Commerce</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Checkout</h1>
        <?php if (empty($_SESSION['cart'])): ?>
            <p class="text-center">Your cart is empty. <a href="index.php">Continue shopping</a></p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($_SESSION['cart'] as $product_id => $quantity) {
                        $sql = "SELECT * FROM products WHERE id = $product_id";
                        $result = $conn->query($sql);
                        $row = $result->fetch_assoc();
                        $subtotal = $row['price'] * $quantity;
                        $total += $subtotal;
                        echo '
                        <tr>
                            <td><img src="assets/images/' . $row['image'] . '" class="img-thumbnail" style="width: 100px; height: auto;" alt="' . $row['name'] . '"></td>
                            <td>' . $row['name'] . '</td>
                            <td>' . $quantity . '</td>
                            <td>Rs. ' . $row['price'] . '</td>
                            <td>Rs. ' . $subtotal . '</td>
                        </tr>';
                    }
                    ?>
                    <tr>
                        <td colspan="4" class="text-end"><strong>Total</strong></td>
                        <td><strong>Rs. <?php echo $total; ?></strong></td>
                    </tr>
                </tbody>
            </table>
            <form action="checkout.php" method="POST">
                <div class="text-end">
                    <button type="submit" class="btn btn-success btn-lg">Proceed to Payment</button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>