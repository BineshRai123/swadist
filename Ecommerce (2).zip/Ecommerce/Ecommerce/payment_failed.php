<?php
session_start();
include 'includes/db.php';

// Payment failed - update order status
if (isset($_SESSION['pending_order_id'])) {
    $order_id = intval($_SESSION['pending_order_id']);
    
    // Update order status to cancelled
    $sql = "UPDATE orders SET status = 'cancelled' WHERE id = $order_id";
    $conn->query($sql);
    
    // Clear session data
    unset($_SESSION['cart']);
    unset($_SESSION['pending_order_id']);
    unset($_SESSION['transaction_uuid']);
    unset($_SESSION['payment_amount']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-danger">
                    <div class="card-body text-center">
                        <div style="font-size: 48px; color: #dc3545; margin-bottom: 20px;">✗</div>
                        <h2 class="text-danger mb-3">Payment Failed!</h2>
                        <p class="lead">Unfortunately, your payment could not be processed.</p>
                        
                        <div class="alert alert-warning">
                            <p>Your order has been cancelled and you can try again.</p>
                        </div>

                        <p class="text-muted">Please check your payment details and try again, or contact our support team if the problem persists.</p>
                        
                        <div class="mt-4">
                            <a href="cart.php" class="btn btn-primary">Back to Cart</a>
                            <a href="index.php" class="btn btn-outline-primary">Continue Shopping</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
