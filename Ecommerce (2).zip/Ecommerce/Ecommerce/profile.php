<?php
session_start();
include 'includes/db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user information
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Get user statistics
$orders_sql = "SELECT COUNT(*) as total_orders, SUM(total_amount) as total_spent FROM orders WHERE user_id = $user_id";
$orders_result = $conn->query($orders_sql);
$orders_stats = $orders_result->fetch_assoc();

$wishlist_sql = "SELECT COUNT(*) as total_wishlist FROM wishlist WHERE user_id = $user_id";
$wishlist_result = $conn->query($wishlist_sql);
$wishlist_stats = $wishlist_result->fetch_assoc();

// Handle profile update
$update_message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    if (empty($name) || empty($email)) {
        $update_message = "Name and email are required.";
        $message_type = 'danger';
    } else {
        $name = $conn->real_escape_string($name);
        $email = $conn->real_escape_string($email);
        $phone = $conn->real_escape_string($phone);
        $address = $conn->real_escape_string($address);
        
        $sql = "UPDATE users SET name = '$name', email = '$email', phone = '$phone', address = '$address' WHERE id = $user_id";
        
        if ($conn->query($sql)) {
            $update_message = "Profile updated successfully!";
            $message_type = 'success';
            
            // Refresh user data
            $result = $conn->query("SELECT * FROM users WHERE id = $user_id");
            $user = $result->fetch_assoc();
        } else {
            $update_message = "Error updating profile. Please try again.";
            $message_type = 'danger';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--mithila-brown) 100%);
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
            border-radius: 10px;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .stat-icon {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 0.9rem;
            color: #7f8c8d;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .profile-form-card {
            background: white;
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }

        .profile-section-title {
            color: var(--primary-color);
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--secondary-color);
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(139,69,19,0.25);
        }

        .btn-update {
            background: linear-gradient(135deg, var(--primary-color), var(--mithila-brown));
            color: white;
            border: none;
            padding: 0.75rem 2rem;
            font-weight: 600;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .btn-update:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(139,69,19,0.3);
            color: white;
            text-decoration: none;
        }

        .info-box {
            background: #f9f5f0;
            border-left: 4px solid var(--secondary-color);
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }

        .info-label {
            color: #7f8c8d;
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.25rem;
        }

        .info-value {
            color: var(--dark-text);
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5 mb-5">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="row align-items-center">
                <div class="col-md-3 text-md-end text-center">
                    <div class="profile-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                </div>
                <div class="col-md-9">
                    <h1 class="mb-2"><?php echo htmlspecialchars($user['name']); ?></h1>
                    <p class="mb-0" style="opacity: 0.9;">
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($user['email']); ?>
                    </p>
                    <p class="mb-0" style="opacity: 0.9;">
                        <i class="fas fa-calendar-alt"></i> Member since <?php echo date('F Y', strtotime($user['created_at'])); ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Statistics Section -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                    <div class="stat-value"><?php echo $orders_stats['total_orders']; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-money-bill"></i></div>
                    <div class="stat-value">Rs. <?php echo number_format($orders_stats['total_spent'] ?? 0, 0); ?></div>
                    <div class="stat-label">Total Spent</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-heart"></i></div>
                    <div class="stat-value"><?php echo $wishlist_stats['total_wishlist']; ?></div>
                    <div class="stat-label">Wishlist Items</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-check"></i></div>
                    <div class="stat-value">Active</div>
                    <div class="stat-label">Account Status</div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="row">
            <!-- Profile Information -->
            <div class="col-md-6">
                <div class="profile-form-card">
                    <h3 class="profile-section-title">
                        <i class="fas fa-info-circle"></i> Account Information
                    </h3>

                    <?php if (!empty($update_message)): ?>
                        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                            <?php echo $update_message; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" 
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-update w-100">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
            </div>

            <!-- Quick Links & Current Info -->
            <div class="col-md-6">
                <div class="profile-form-card">
                    <h3 class="profile-section-title">
                        <i class="fas fa-link"></i> Quick Links
                    </h3>

                    <a href="orders.php" class="btn btn-outline-primary w-100 mb-3">
                        <i class="fas fa-history"></i> View Order History
                    </a>
                    <a href="wishlist.php" class="btn btn-outline-primary w-100 mb-3">
                        <i class="fas fa-heart"></i> My Wishlist
                    </a>
                    <a href="cart.php" class="btn btn-outline-primary w-100 mb-3">
                        <i class="fas fa-shopping-cart"></i> View Cart
                    </a>
                    <a href="index.php" class="btn btn-outline-primary w-100 mb-3">
                        <i class="fas fa-shopping-bag"></i> Continue Shopping
                    </a>

                    <hr>

                    <h5 class="mt-4 mb-3" style="color: var(--primary-color);">
                        <i class="fas fa-shield-alt"></i> Account Settings
                    </h5>

                    <div class="info-box">
                        <div class="info-label">Account Created</div>
                        <div class="info-value">
                            <?php echo date('F d, Y', strtotime($user['created_at'])); ?>
                        </div>
                    </div>

                    <div class="info-box">
                        <div class="info-label">User ID</div>
                        <div class="info-value">#<?php echo $user['id']; ?></div>
                    </div>

                    <div class="info-box">
                        <div class="info-label">Email Verified</div>
                        <div class="info-value">
                            <span class="badge bg-success">
                                <i class="fas fa-check-circle"></i> Verified
                            </span>
                        </div>
                    </div>

                    <a href="logout.php" class="btn btn-danger w-100 mt-4">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
