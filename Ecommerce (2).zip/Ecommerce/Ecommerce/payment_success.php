<?php
session_start();
include 'includes/db.php';

// Check if payment was successful
if (!isset($_GET['data'])) {
    header("Location: orders.php?message=invalid");
    exit();
}

// Decode eSewa response
$response = json_decode(base64_decode($_GET['data']), true);

// eSewa Demo Configuration
$MERCHANT_SECRET_KEY = "8gBm/:&EnhH.1/q";

// Verify transaction
if (isset($response['transaction_code']) && isset($response['status']) && $response['status'] == 'COMPLETE') {
    
    // Verify signature
    $signature_data = "total_amount=" . $response['total_amount'] . ",transaction_uuid=" . $response['transaction_uuid'] . ",product_code=" . $response['product_code'];
    $signature = base64_encode(hash_hmac('sha256', $signature_data, $MERCHANT_SECRET_KEY, true));

    if (isset($response['signature']) && $response['signature'] === $signature) {
        
        // Update order status to completed
        $order_id = $_SESSION['pending_order_id'];
        $transaction_code = $response['transaction_code'];
        
        $sql = "UPDATE orders SET status = 'completed' WHERE id = $order_id AND user_id = " . $_SESSION['user_id'];
        if ($conn->query($sql)) {
            // Clear session data
            unset($_SESSION['cart']);
            unset($_SESSION['pending_order_id']);
            unset($_SESSION['transaction_uuid']);
            unset($_SESSION['payment_amount']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - Swadist Mithila Snacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-success">
                    <div class="card-body text-center">
                        <div style="font-size: 48px; color: #28a745; margin-bottom: 20px;">✓</div>
                        <h2 class="text-success mb-3">Payment Successful!</h2>
                        <p class="lead">Thank you for your purchase.</p>
                        
                        <div class="alert alert-info">
                            <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order_id); ?></p>
                            <p><strong>Transaction Code:</strong> <?php echo htmlspecialchars($transaction_code); ?></p>
                            <p><strong>Amount:</strong> Rs. <?php echo htmlspecialchars($response['total_amount']); ?></p>
                            <p><strong>Status:</strong> <span class="badge bg-success">Completed</span></p>
                        </div>

                        <p class="text-muted">Your order has been confirmed and will be processed shortly.</p>
                        
                        <div class="mt-4">
                            <a href="orders.php" class="btn btn-primary">View Orders</a>
                            <a href="index.php" class="btn btn-outline-primary">Continue Shopping</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
        } else {
            header("Location: orders.php?message=error");
            exit();
        }
    } else {
        header("Location: orders.php?message=invalid_signature");
        exit();
    }
} else {
    header("Location: orders.php?message=payment_failed");
    exit();
}
?>
