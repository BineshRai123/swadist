<?php 
session_start();
include 'includes/db.php';
include 'recommend.php';

// Get user ID if logged in
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Mithila Snacks Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Mithila Hero Section -->
    <section class="hero" style="background: linear-gradient(135deg, rgba(139,69,19,0.9), rgba(160,82,45,0.9)), url('data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 1200 400%22><defs><pattern id=%22pattern%22 x=%220%22 y=%220%22 width=%22100%22 height=%22100%22 patternUnits=%22userSpaceOnUse%22><circle cx=%2250%22 cy=%2250%22 r=%2230%22 fill=%22rgba(255,255,255,0.05)%22/></pattern></defs><rect width=%221200%22 height=%22400%22 fill=%22%23A0522D%22/><rect width=%221200%22 height=%22400%22 fill=%22url(%23pattern)%22/></svg>'); background-size: cover; background-position: center;">
        <div class="container py-5 text-center text-white">
            <div class="mb-3">
                <h3 class="mb-2" style="font-size: 1.5rem; letter-spacing: 2px;">Authentic Mithila Snacks</h3>
            </div>
            <h1 class="display-4 fw-bold mb-3">Welcome to SWADIST</h1>
            <p class="lead mb-2">Authentic Mithila Snacks</p>
            <p class="fs-5 mb-4" style="opacity: 0.95;">
                Experience the rich culinary heritage of the Mithila region. 
                Each snack is crafted with traditional recipes and premium ingredients.
            </p>
            <p class="fs-6 mb-4" style="color: #FFD700; font-style: italic;">
                Traditional flavors brought to your home
            </p>
            <a href="#featured" class="btn btn-warning btn-lg fw-bold">
                <i class="fas fa-shopping-bag"></i> Explore Now
            </a>
        </div>
    </section>

    <!-- Cultural Information Section -->
    <section class="py-5" style="background-color: #f9f5f0;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-center mb-4">
                    <div class="mb-3">
                        <i class="fas fa-leaf" style="font-size: 3rem; color: #8B4513;"></i>
                    </div>
                    <h5 class="fw-bold">Pure Ingredients</h5>
                    <p class="text-muted small">
                        We use 100% natural, organic ingredients sourced from local farmers in the Mithila region.
                    </p>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="mb-3">
                        <i class="fas fa-heart" style="font-size: 3rem; color: #e74c3c;"></i>
                    </div>
                    <h5 class="fw-bold">Traditional Recipes</h5>
                    <p class="text-muted small">
                        Authentic recipes passed down through generations in the Mithila community.
                    </p>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="mb-3">
                        <i class="fas fa-award" style="font-size: 3rem; color: #FFD700;"></i>
                    </div>
                    <h5 class="fw-bold">Quality Assured</h5>
                    <p class="text-muted small">
                        Every product is carefully crafted and quality tested to ensure excellence.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container mt-5" id="featured">
        <h2 class="text-center mb-4 fw-bold" style="color: #8B4513;">
            <i class="fas fa-star" style="color: #FFD700;"></i> Featured Mithila Snacks
        </h2>
        <div class="row" id="products-container">
            <?php
            // Get total number of products
            $total_sql = "SELECT COUNT(*) as total FROM products";
            $total_result = $conn->query($total_sql);
            $total_row = $total_result->fetch_assoc();
            $total_products = $total_row['total'];
            
            // Get 3 random products initially
            $sql = "SELECT * FROM products ORDER BY RAND() LIMIT 3";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <div class="col-md-4 mb-4 product-item">
                        <div class="card product-card">
                            <div class="product-card-img-wrapper">
                                <img src="assets/images/' . htmlspecialchars($row['image']) . '" class="card-img-top" alt="' . htmlspecialchars($row['name']) . '">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">' . htmlspecialchars($row['name']) . '</h5>
                                <p class="card-text text-muted small">' . htmlspecialchars(substr($row['description'], 0, 60)) . '...</p>
                                <p class="product-price">Rs. ' . number_format($row['price'], 2) . '</p>
                                <a href="product.php?id=' . $row['id'] . '" class="btn btn-primary w-100">
                                    <i class="fas fa-eye"></i> View Product
                                </a>
                            </div>
                        </div>
                    </div>';
                }
            } else {
                echo "<p class='text-center col-12'>No products found.</p>";
            }
            ?>
        </div>
        
        <!-- Show More Button (only if there are more than 3 products) -->
        <?php if ($total_products > 3): ?>
        <div class="text-center mt-4" id="show-more-section">
            <button class="btn btn-lg btn-outline-primary" id="show-more-btn" onclick="showMoreProducts()">
                <i class="fas fa-plus"></i> Show More Products
            </button>
        </div>
        <?php endif; ?>
    </div>

    <!-- Recommended Products Section -->
    <?php if ($user_id): ?>
    <div class="container mt-5 mb-5">
        <h2 class="text-center mb-4">Recommended for You</h2>
        <div class="row">
            <?php
            $recommender = new ProductRecommendation($conn, $user_id);
            $recommended_products = $recommender->getRecommendations(3);
            
            if (!empty($recommended_products)) {
                foreach ($recommended_products as $product) {
                    echo '
                    <div class="col-md-4 mb-4">
                        <div class="card product-card border-info">
                            <div class="badge bg-info position-absolute" style="top: 10px; right: 10px;">Recommended</div>
                            <img src="assets/images/' . $product['image'] . '" class="card-img-top" alt="' . $product['name'] . '">
                            <div class="card-body">
                                <h5 class="card-title">' . $product['name'] . '</h5>
                                <p class="card-text">' . substr($product['description'], 0, 80) . '...</p>
                                <p class="card-text"><strong>Rs. ' . $product['price'] . '</strong></p>
                                <a href="product.php?id=' . $product['id'] . '" class="btn btn-outline-info">View Product</a>
                            </div>
                        </div>
                    </div>';
                }
            }
            ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Trending Products -->
    <div class="container mt-5 mb-5">
        <h2 class="text-center mb-4">Hot Picks</h2>
        <div class="row">
            <?php
            $recommender = new ProductRecommendation($conn, $user_id ? $user_id : 0);
            $trending = $recommender->getRecommendations(3);
            
            if (empty($trending)) {
                // Fallback to all products ordered by price
                $sql = "SELECT p.* FROM products p ORDER BY p.price DESC LIMIT 3";
                $trending_result = $conn->query($sql);
                $trending = array();
                while ($row = $trending_result->fetch_assoc()) {
                    $trending[] = $row;
                }
            }
            
            foreach ($trending as $product) {
                echo '
                <div class="col-md-4 mb-4">
                    <div class="card product-card" style="border-color: #ff6b6b;">
                        <div class="badge bg-danger position-absolute" style="top: 10px; right: 10px;">Hot</div>
                        <img src="assets/images/' . $product['image'] . '" class="card-img-top" alt="' . $product['name'] . '">
                        <div class="card-body">
                            <h5 class="card-title">' . $product['name'] . '</h5>
                            <p class="card-text">' . substr($product['description'], 0, 80) . '...</p>
                            <p class="card-text"><strong>Rs. ' . $product['price'] . '</strong></p>
                            <a href="product.php?id=' . $product['id'] . '" class="btn btn-danger">View Product</a>
                        </div>
                    </div>
                </div>';
            }
            ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
    
    <script>
        let allProductsLoaded = false;
        
        function showMoreProducts() {
            const container = document.getElementById('products-container');
            const btn = document.getElementById('show-more-btn');
            
            // Fetch all products via AJAX
            fetch('get_all_products.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear existing products and add all
                        container.innerHTML = '';
                        
                        data.products.forEach(product => {
                            const productHTML = `
                                <div class="col-md-4 mb-4 product-item">
                                    <div class="card product-card">
                                        <div class="product-card-img-wrapper">
                                            <img src="assets/images/${product.image}" class="card-img-top" alt="${product.name}">
                                        </div>
                                        <div class="card-body">
                                            <h5 class="card-title">${product.name}</h5>
                                            <p class="card-text text-muted small">${product.description.substring(0, 60)}...</p>
                                            <p class="product-price">Rs. ${parseFloat(product.price).toFixed(2)}</p>
                                            <a href="product.php?id=${product.id}" class="btn btn-primary w-100">
                                                <i class="fas fa-eye"></i> View Product
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            `;
                            container.innerHTML += productHTML;
                        });
                        
                        // Hide the button and show a collapse opti
on
                        document.getElementById('show-more-section').innerHTML = `
                            <button class="btn btn-lg btn-outline-secondary" onclick="showFeaturedOnly()">
                                <i class="fas fa-compress"></i> Show Featured Only
                            </button>
                        `;
                        
                        allProductsLoaded = true;
                    }
                })
                .catch(error => console.error('Error:', error));
        }
        
        function showFeaturedOnly() {
            // Reload the page to show only featured products again
            location.reload();
        }
    </script>
</body>
</html>