<?php
/**
 * AJAX endpoint to fetch all products
 * Called by the "Show More" button on the homepage
 */

include 'includes/db.php';

header('Content-Type: application/json');

try {
    // Get all products ordered by creation date (newest first)
    $sql = "SELECT id, name, description, price, image FROM products ORDER BY created_at DESC";
    $result = $conn->query($sql);
    
    $products = array();
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = array(
                'id' => $row['id'],
                'name' => htmlspecialchars($row['name']),
                'description' => htmlspecialchars($row['description']),
                'price' => $row['price'],
                'image' => htmlspecialchars($row['image'])
            );
        }
    }
    
    echo json_encode(array(
        'success' => true,
        'products' => $products,
        'count' => count($products)
    ));
    
} catch (Exception $e) {
    echo json_encode(array(
        'success' => false,
        'error' => $e->getMessage()
    ));
}

$conn->close();
?>
