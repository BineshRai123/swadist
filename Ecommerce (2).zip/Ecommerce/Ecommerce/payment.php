<?php
session_start();
include 'includes/db.php';

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit();
}

/**
 * eSewa Official Test Credentials
 * Reference: https://developer.esewa.com.np/pages/Test-credentials
 * 
 * For Testing:
 * - eSewa ID: 9806800001 (or 9806800002, 9806800003, 9806800004, 9806800005)
 * - Password: Nepal@123
 * - MPIN: 1122
 * - Merchant Code (Service Code): EPAYTEST
 * - Secret Key: 8gBm/:&EnhH.1/q
 * - Token: 123456
 * 
 * For Production - Contact eSewa after testing
 */

// eSewa Configuration - TESTING (UAT)
$MERCHANT_CODE = "EPAYTEST";
$SECRET_KEY = "8gBm/:&EnhH.1/q";
$ESEWA_PAYMENT_URL = "https://uat.esewa.com.np/epay/main";

// For Production (after testing verified), change to:
// $ESEWA_PAYMENT_URL = "https://esewa.com.np/epay/main";

// Calculate total amount
$user_id = $_SESSION['user_id'];
$total_amount = 0;

foreach ($_SESSION['cart'] as $product_id => $quantity) {
    $sql = "SELECT price FROM products WHERE id = $product_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $total_amount += $row['price'] * $quantity;
}

// Create pending order
$sql = "INSERT INTO orders (user_id, total_amount, status) VALUES ($user_id, $total_amount, 'pending')";
if ($conn->query($sql)) {
    $order_id = $conn->insert_id;

    // Insert order items
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $sql = "SELECT price FROM products WHERE id = $product_id";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $price = $row['price'];

        $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($order_id, $product_id, $quantity, $price)";
        $conn->query($sql);
    }

    // Generate unique transaction UUID
    $transaction_uuid = "SWADIST_" . $order_id . "_" . time();
    $product_code = "EPAYTEST";
    $amount = round($total_amount, 2);
    $tax_amount = 0;
    $service_charge = 0;
    $total = $amount + $tax_amount + $service_charge;
    
    // Callback URLs - must be publicly accessible for eSewa to reach
    $success_url = "http://" . $_SERVER['HTTP_HOST'] . "/Ecommerce/payment_success.php";
    $failure_url = "http://" . $_SERVER['HTTP_HOST'] . "/Ecommerce/payment_failed.php";
    
    $signed_field_names = "total_amount,transaction_uuid,product_code";
    
    // Store order details for verification
    $_SESSION['pending_order_id'] = $order_id;
    $_SESSION['transaction_uuid'] = $transaction_uuid;
    $_SESSION['payment_amount'] = $total;

    // Create HMAC-SHA256 signature as per eSewa spec
    $signature_data = "total_amount=$total,transaction_uuid=$transaction_uuid,product_code=$product_code";
    $signature = base64_encode(hash_hmac('sha256', $signature_data, $SECRET_KEY, true));

    // Clear cart
    unset($_SESSION['cart']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Processing - Mithila Snacks Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body text-center">
                        <h3 class="mb-4">Payment Options</h3>
                        <p>Order ID: <strong><?php echo $order_id; ?></strong></p>
                        <p>Amount: <strong>Rs. <?php echo $amount; ?></strong></p>
                    </div>
                </div>

                <!-- Payment Options -->
                <div class="row mt-4">
                    <!-- eSewa Option -->
                    <div class="col-md-6">
                        <form id="esewa_form" action="<?php echo $ESEWA_PAYMENT_URL; ?>" method="POST" style="display:none;">
                            <input type="hidden" id="amount" name="amount" value="<?php echo $amount; ?>">
                            <input type="hidden" id="tax_amount" name="tax_amount" value="<?php echo $tax_amount; ?>">
                            <input type="hidden" id="total_amount" name="total_amount" value="<?php echo $amount + $tax_amount + $service_charge; ?>">
                            <input type="hidden" id="transaction_uuid" name="transaction_uuid" value="<?php echo $transaction_uuid; ?>">
                            <input type="hidden" id="product_code" name="product_code" value="<?php echo $product_code; ?>">
                            <input type="hidden" id="product_service_charge" name="product_service_charge" value="<?php echo $service_charge; ?>">
                            <input type="hidden" id="product_delivery_charge" name="product_delivery_charge" value="0">
                            <input type="hidden" id="success_url" name="success_url" value="<?php echo $success_url; ?>">
                            <input type="hidden" id="failure_url" name="failure_url" value="<?php echo $failure_url; ?>">
                            <input type="hidden" id="signed_field_names" name="signed_field_names" value="<?php echo $signed_field_names; ?>">
                            <input type="hidden" id="signature" name="signature" value="<?php echo $signature; ?>">
                        </form>
                        <button class="btn btn-success btn-block w-100 mb-3" onclick="submitEsewa()">
                            <i class="fas fa-money-bill"></i> Pay with eSewa
                        </button>
                    </div>

                    <!-- Test/Demo Payment Option -->
                    <div class="col-md-6">
                        <form action="payment_test.php" method="POST">
                            <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                            <input type="hidden" name="amount" value="<?php echo $amount; ?>">
                            <button type="submit" class="btn btn-info btn-block w-100 mb-3">
                                <i class="fas fa-vial"></i> Test Payment
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Payment Details -->
                <div class="card mt-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Payment Details</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Order ID:</strong> #<?php echo $order_id; ?></p>
                        <p><strong>Amount:</strong> Rs. <?php echo number_format($amount, 2); ?></p>
                        <p><strong>Status:</strong> <span class="badge bg-warning">Pending Payment</span></p>
                        <p class="text-muted small mb-0">Choose a payment method above to proceed.</p>
                    </div>
                </div>

                <!-- Test Credentials Help -->
                <div class="card mt-3 bg-light border-info">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0"><i class="fas fa-info-circle"></i> eSewa Test Credentials</h6>
                    </div>
                    <div class="card-body small">
                        <p class="mb-2"><strong>For Testing Payment via eSewa:</strong></p>
                        <p class="mb-1"><strong>eSewa ID:</strong> 9806800001 (or 9806800002-9806800005)</p>
                        <p class="mb-1"><strong>Password:</strong> Nepal@123</p>
                        <p class="mb-1"><strong>MPIN:</strong> 1122</p>
                        <p class="mb-2"><strong>Reference:</strong> <a href="https://developer.esewa.com.np/" target="_blank">eSewa Developer Docs</a></p>
                        <div style="background: white; padding: 0.75rem; border-left: 3px solid #0d6efd; margin-top: 0.5rem;">
                            <p class="mb-0"><strong>Note:</strong> This is UAT (Testing) mode. Funds will not be deducted. For production, contact eSewa.</p>
                        </div>
                    </div>
                </div>

                <div class="mt-3 text-center">
                    <a href="cart.php" class="btn btn-outline-secondary">Back to Cart</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function submitEsewa() {
            if (confirm('You will be redirected to eSewa payment gateway. Continue?')) {
                document.getElementById('esewa_form').submit();
            }
        }
    </script>
</body>
</html>

<?php
} else {
    echo "<div class='alert alert-danger'>Error creating order. Please try again.</div>";
}
?>
