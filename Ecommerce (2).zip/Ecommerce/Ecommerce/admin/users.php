<?php
session_start();
include '../includes/db.php';

// Check admin access
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

// Handle CRUD Operations
$action = isset($_GET['action']) ? $_GET['action'] : '';
$message = '';
$message_type = '';

// Create User
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_user'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    if ($conn->query($sql)) {
        $message = "User created successfully!";
        $message_type = "success";
    } else {
        $message = "Error creating user: " . $conn->error;
        $message_type = "danger";
    }
}

// Update User
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $sql = "UPDATE users SET name='$name', email='$email', password='$password' WHERE id=$user_id";
    } else {
        $sql = "UPDATE users SET name='$name', email='$email' WHERE id=$user_id";
    }

    if ($conn->query($sql)) {
        $message = "User updated successfully!";
        $message_type = "success";
    } else {
        $message = "Error updating user: " . $conn->error;
        $message_type = "danger";
    }
}

// Delete User
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM users WHERE id=$delete_id";
    if ($conn->query($sql)) {
        $message = "User deleted successfully!";
        $message_type = "success";
    } else {
        $message = "Error deleting user: " . $conn->error;
        $message_type = "danger";
    }
}

// Get user for editing
$edit_user = null;
if ($action == 'edit' && isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $result = $conn->query("SELECT * FROM users WHERE id=$user_id");
    $edit_user = $result->fetch_assoc();
}

// Get all users
$users_result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Swadist Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="d-flex">
        <nav class="sidebar bg-dark text-white">
            <div class="sidebar-header p-3 border-bottom">
                <h5 class="mb-0"><i class="fas fa-crown"></i> Swadist Admin</h5>
            </div>
            <ul class="nav flex-column p-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="users.php"><i class="fas fa-users"></i> Users</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="products.php"><i class="fas fa-box"></i> Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a>
                </li>
                <li class="nav-item border-top mt-3 pt-3">
                    <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="flex-fill">
            <nav class="navbar navbar-dark bg-dark shadow-sm">
                <div class="container-fluid">
                    <span class="navbar-text text-white">User Management | <?php echo date('F j, Y'); ?></span>
                </div>
            </nav>

            <div class="admin-content p-4">
                <div class="container-fluid">
                    <!-- Header -->
                    <div class="mb-4">
                        <h1>User Management</h1>
                    </div>

                    <!-- Messages -->
                    <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>

                    <!-- Users Table -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">All Users (<?php echo $users_result->num_rows; ?>)</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Joined</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $counter = 1;
                                        while ($user = $users_result->fetch_assoc()):
                                        ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td><strong><?php echo htmlspecialchars($user['name']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="#" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#userModal" onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>
                                                    <a href="?delete_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit User Modal -->
    <div class="modal fade" id="userModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" id="user_id" name="user_id">
                        
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password <span id="passwordNote" class="text-muted">(Leave blank to keep current)</span></label>
                            <input type="password" id="password" name="password" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="submitBtn" name="create_user" class="btn btn-primary">Add User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editUser(user) {
            document.getElementById('user_id').value = user.id;
            document.getElementById('name').value = user.name;
            document.getElementById('email').value = user.email;
            document.getElementById('modalTitle').textContent = 'Edit User';
            document.getElementById('submitBtn').name = 'update_user';
            document.getElementById('submitBtn').textContent = 'Update User';
            document.getElementById('passwordNote').innerHTML = '(Leave blank to keep current)';
        }

        // Reset form on modal close
        document.getElementById('userModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('user_id').value = '';
            document.querySelector('form').reset();
            document.getElementById('modalTitle').textContent = 'Add New User';
            document.getElementById('submitBtn').name = 'create_user';
            document.getElementById('submitBtn').textContent = 'Add User';
        });
    </script>
</body>
</html>
