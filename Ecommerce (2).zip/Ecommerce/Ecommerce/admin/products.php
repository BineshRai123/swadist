<?php
session_start();
include '../includes/db.php';

// Check admin access
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$message = '';
$message_type = '';

// Create Product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_product'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $price = $_POST['price'];
    $image = $_POST['image'] ?? 'product_default.jpg';

    $sql = "INSERT INTO products (name, description, price, image) VALUES ('$name', '$description', $price, '$image')";
    if ($conn->query($sql)) {
        $message = "Product added successfully!";
        $message_type = "success";
    } else {
        $message = "Error adding product: " . $conn->error;
        $message_type = "danger";
    }
}

// Update Product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    $product_id = $_POST['product_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $price = $_POST['price'];
    $image = $_POST['image'];

    $sql = "UPDATE products SET name='$name', description='$description', price=$price, image='$image' WHERE id=$product_id";
    if ($conn->query($sql)) {
        $message = "Product updated successfully!";
        $message_type = "success";
    } else {
        $message = "Error updating product: " . $conn->error;
        $message_type = "danger";
    }
}

// Delete Product
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    
    // Start transaction to handle cascading deletes
    $conn->begin_transaction();
    
    try {
        // First, delete from order_items that reference this product
        $sql1 = "DELETE FROM order_items WHERE product_id = $delete_id";
        $conn->query($sql1);
        
        // Then, delete from cart that references this product
        $sql2 = "DELETE FROM cart WHERE product_id = $delete_id";
        $conn->query($sql2);
        
        // Then, delete from wishlist that references this product
        $sql3 = "DELETE FROM wishlist WHERE product_id = $delete_id";
        $conn->query($sql3);
        
        // Finally, delete the product itself
        $sql4 = "DELETE FROM products WHERE id = $delete_id";
        if ($conn->query($sql4)) {
            $conn->commit();
            $message = "Product and all associated data deleted successfully!";
            $message_type = "success";
        } else {
            $conn->rollback();
            $message = "Error deleting product: " . $conn->error;
            $message_type = "danger";
        }
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error deleting product: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Get products
$products_result = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Swadist Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="d-flex">
        <nav class="sidebar bg-dark text-white">
            <div class="sidebar-header p-3 border-bottom">
                <h5 class="mb-0"><i class="fas fa-crown"></i> Swadist Admin</h5>
            </div>
            <ul class="nav flex-column p-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="users.php"><i class="fas fa-users"></i> Users</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="products.php"><i class="fas fa-box"></i> Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a>
                </li>
                <li class="nav-item border-top mt-3 pt-3">
                    <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="flex-fill">
            <nav class="navbar navbar-dark bg-dark shadow-sm">
                <div class="container-fluid">
                    <span class="navbar-text text-white">Product Management | <?php echo date('F j, Y'); ?></span>
                </div>
            </nav>

            <div class="admin-content p-4">
                <div class="container-fluid">
                    <!-- Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1>Product Management</h1>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#productModal">
                            <i class="fas fa-plus"></i> Add New Product
                        </button>
                    </div>

                    <!-- Messages -->
                    <?php if (!empty($message)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>

                    <!-- Products Table -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">All Products (<?php echo $products_result->num_rows; ?>)</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Product Name</th>
                                            <th>Price</th>
                                            <th>Image</th>
                                            <th>Added</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $counter = 1;
                                        while ($product = $products_result->fetch_assoc()):
                                        ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                            <td>Rs. <?php echo number_format($product['price'], 2); ?></td>
                                            <td>
                                                <img src="../assets/images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;">
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($product['created_at'])); ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="#" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#productModal" onclick="editProduct(<?php echo htmlspecialchars(json_encode($product)); ?>)">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>
                                                    <a href="?delete_id=<?php echo $product['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit Product Modal -->
    <div class="modal fade" id="productModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="productModalTitle">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" id="product_id" name="product_id">
                        
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" id="product_name" name="name" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea id="product_description" name="description" class="form-control" rows="4" required></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Price (Rs.)</label>
                                <input type="number" id="product_price" name="price" step="0.01" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Image File</label>
                                <input type="text" id="product_image" name="image" class="form-control" placeholder="e.g., product1.jpg">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="productSubmitBtn" name="create_product" class="btn btn-success">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editProduct(product) {
            document.getElementById('product_id').value = product.id;
            document.getElementById('product_name').value = product.name;
            document.getElementById('product_description').value = product.description;
            document.getElementById('product_price').value = product.price;
            document.getElementById('product_image').value = product.image;
            document.getElementById('productModalTitle').textContent = 'Edit Product';
            document.getElementById('productSubmitBtn').name = 'update_product';
            document.getElementById('productSubmitBtn').textContent = 'Update Product';
        }

        // Reset form on modal close
        document.getElementById('productModal').addEventListener('hidden.bs.modal', function() {
            document.getElementById('product_id').value = '';
            document.querySelector('#productModal form').reset();
            document.getElementById('productModalTitle').textContent = 'Add New Product';
            document.getElementById('productSubmitBtn').name = 'create_product';
            document.getElementById('productSubmitBtn').textContent = 'Add Product';
        });
    </script>
</body>
</html>
