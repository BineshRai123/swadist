<?php
session_start();
include '../includes/db.php';

// Check admin access
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

// Update Order Status
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_order'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    
    $sql = "UPDATE orders SET status='$status' WHERE id=$order_id";
    if ($conn->query($sql)) {
        $message = "Order status updated!";
        $message_type = "success";
    }
}

$message = $_POST['update_order'] ?? '';
$message_type = isset($_POST['update_order']) ? 'success' : '';

// Get all orders with user details
$orders_result = $conn->query("
    SELECT o.*, u.name, u.email 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Swadist Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="d-flex">
        <nav class="sidebar bg-dark text-white">
            <div class="sidebar-header p-3 border-bottom">
                <h5 class="mb-0"><i class="fas fa-crown"></i> Swadist Admin</h5>
            </div>
            <ul class="nav flex-column p-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="users.php"><i class="fas fa-users"></i> Users</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="products.php"><i class="fas fa-box"></i> Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a>
                </li>
                <li class="nav-item border-top mt-3 pt-3">
                    <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="flex-fill">
            <nav class="navbar navbar-dark bg-dark shadow-sm">
                <div class="container-fluid">
                    <span class="navbar-text text-white">Order Management | <?php echo date('F j, Y'); ?></span>
                </div>
            </nav>

            <div class="admin-content p-4">
                <div class="container-fluid">
                    <!-- Header -->
                    <div class="mb-4">
                        <h1>Order Management</h1>
                    </div>

                    <!-- Messages -->
                    <?php if (!empty($message_type)): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                        Order status updated successfully!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>

                    <!-- Orders Table -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">All Orders (<?php echo $orders_result->num_rows; ?>)</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Order ID</th>
                                            <th>Customer</th>
                                            <th>Email</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $counter = 1;
                                        while ($order = $orders_result->fetch_assoc()):
                                            $badge_class = $order['status'] == 'completed' ? 'bg-success' : ($order['status'] == 'pending' ? 'bg-warning' : 'bg-danger');
                                        ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td><strong>#<?php echo $order['id']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($order['name']); ?></td>
                                            <td><?php echo htmlspecialchars($order['email']); ?></td>
                                            <td>Rs. <?php echo number_format($order['total_amount'], 2); ?></td>
                                            <td>
                                                <span class="badge <?php echo $badge_class; ?>" style="text-transform: capitalize;">
                                                    <?php echo $order['status']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                    <select name="status" class="form-select form-select-sm" style="width: auto; display: inline-block;">
                                                        <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                        <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                        <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                    </select>
                                                    <button type="submit" name="update_order" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-check"></i> Update
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
