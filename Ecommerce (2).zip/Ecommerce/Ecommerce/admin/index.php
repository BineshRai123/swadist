<?php
session_start();
include '../includes/db.php';

// Only allow admin users
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

// Fetch dashboard statistics
$total_users_result = $conn->query("SELECT COUNT(*) as count FROM users");
$total_users = $total_users_result->fetch_assoc()['count'];

$total_products_result = $conn->query("SELECT COUNT(*) as count FROM products");
$total_products = $total_products_result->fetch_assoc()['count'];

$total_orders_result = $conn->query("SELECT COUNT(*) as count FROM orders");
$total_orders = $total_orders_result->fetch_assoc()['count'];

$total_revenue_result = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'");
$total_revenue = $total_revenue_result->fetch_assoc()['total'] ?? 0;

$pending_orders_result = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'");
$pending_orders = $pending_orders_result->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Swadist</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="d-flex">
        <nav class="sidebar bg-dark text-white">
            <div class="sidebar-header p-3 border-bottom">
                <h5 class="mb-0">
                    <i class="fas fa-crown"></i> Swadist Admin
                </h5>
            </div>
            <ul class="nav flex-column p-0">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">
                        <i class="fas fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-users"></i> Users
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="products.php">
                        <i class="fas fa-box"></i> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="orders.php">
                        <i class="fas fa-shopping-cart"></i> Orders
                    </a>
                </li>
                <li class="nav-item border-top mt-3 pt-3">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="flex-fill">
            <!-- Top Navigation -->
            <nav class="navbar navbar-dark bg-dark shadow-sm">
                <div class="container-fluid">
                    <span class="navbar-text text-white">
                        Welcome, Admin | <?php echo date('F j, Y'); ?>
                    </span>
                </div>
            </nav>

            <!-- Content Area -->
            <div class="admin-content p-4">
                <div class="container-fluid">
                    <h1 class="mb-4">Dashboard</h1>

                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <!-- Total Users -->
                        <div class="col-md-3 mb-3">
                            <div class="stat-card card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="text-muted mb-1">Total Users</h6>
                                            <h3 class="mb-0"><?php echo $total_users; ?></h3>
                                        </div>
                                        <div class="stat-icon bg-primary">
                                            <i class="fas fa-users text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Products -->
                        <div class="col-md-3 mb-3">
                            <div class="stat-card card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="text-muted mb-1">Total Products</h6>
                                            <h3 class="mb-0"><?php echo $total_products; ?></h3>
                                        </div>
                                        <div class="stat-icon bg-success">
                                            <i class="fas fa-box text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Orders -->
                        <div class="col-md-3 mb-3">
                            <div class="stat-card card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="text-muted mb-1">Total Orders</h6>
                                            <h3 class="mb-0"><?php echo $total_orders; ?></h3>
                                        </div>
                                        <div class="stat-icon bg-info">
                                            <i class="fas fa-shopping-cart text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Revenue -->
                        <div class="col-md-3 mb-3">
                            <div class="stat-card card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="text-muted mb-1">Total Revenue</h6>
                                            <h3 class="mb-0">Rs. <?php echo number_format($total_revenue, 2); ?></h3>
                                        </div>
                                        <div class="stat-icon bg-warning">
                                            <i class="fas fa-money-bill text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions & Pending Orders -->
                    <div class="row">
                        <!-- Quick Actions -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-dark text-white">
                                    <h5 class="mb-0">Quick Actions</h5>
                                </div>
                                <div class="card-body">
                                    <a href="products.php?action=add" class="btn btn-success btn-block mb-2 w-100">
                                        <i class="fas fa-plus"></i> Add New Product
                                    </a>
                                    <a href="orders.php" class="btn btn-info btn-block w-100">
                                        <i class="fas fa-eye"></i> View All Orders
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Orders -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-dark text-white">
                                    <h5 class="mb-0">Pending Orders</h5>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-warning mb-0">
                                        <h3 class="mb-0"><?php echo $pending_orders; ?> Orders</h3>
                                        <p class="text-muted mb-0">Awaiting payment confirmation</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>