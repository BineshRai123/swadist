<?php
/**
 * Product Recommendation Algorithm
 * Content-Based Filtering: Recommends products similar to user's purchase history
 */

class ProductRecommendation {
    private $conn;
    private $user_id;

    public function __construct($connection, $user_id) {
        $this->conn = $connection;
        $this->user_id = $user_id;
    }

    /**
     * Get personalized product recommendations using Content-Based Filtering
     * @param int $limit - Number of recommendations to return
     * @return array - Array of recommended products
     */
    public function getRecommendations($limit = 3) {
        return $this->getContentBasedRecommendations($limit);
    }


    /**
     * Content-Based Filtering: Recommend products similar to user's purchases
     */
    private function getContentBasedRecommendations($limit) {
        $sql = "
            SELECT DISTINCT p.* FROM products p
            WHERE p.id NOT IN (
                SELECT DISTINCT oi.product_id FROM order_items oi
                JOIN orders o ON oi.order_id = o.id
                WHERE o.user_id = " . $this->user_id . "
            )
            ORDER BY p.price DESC
            LIMIT " . $limit;

        $result = $this->conn->query($sql);
        $recommendations = array();
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $recommendations[] = $row;
            }
        }
        
        return $recommendations;
    }




}
?>
