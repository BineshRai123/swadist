    <!-- Footer -->
    <footer style="background: linear-gradient(135deg, #8B4513 0%, #A0522D 100%); color: #fff;">
        <div class="container py-5">
            <div class="row mb-4">
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">
                        <i class="fas fa-home"></i> SWADIST
                    </h5>
                    <p class="small">
                        Authentic Mithila snacks bringing traditional flavors from the heart of Nepal to your table. 
                        Every bite tells the story of Mithila's rich culinary heritage.
                    </p>
                    <p class="small text-warning">
                        <em>"मिथिलाको स्वाद, हरेकको घरमा"</em> <br>
                        (Mithila's Taste, In Every Home)
                    </p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">
                        <i class="fas fa-utensils"></i> Our Specialties
                    </h5>
                    <ul class="list-unstyled small">
                        <li><i class="fas fa-check text-warning"></i> Traditional Dry Snacks</li>
                        <li><i class="fas fa-check text-warning"></i> Pure & Organic Ingredients</li>
                        <li><i class="fas fa-check text-warning"></i> No Artificial Preservatives</li>
                        <li><i class="fas fa-check text-warning"></i> Authentic Mithila Recipes</li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-3">
                        <i class="fas fa-phone"></i> Contact
                    </h5>
                    <p class="small">
                        <i class="fas fa-map-marker-alt"></i> Satungal, Kathmandu 20<br>
                        <i class="fas fa-envelope"></i> info@swadist.com<br>
                        <i class="fas fa-phone"></i> +977-9812345678
                    </p>
                </div>
            </div>
            <hr style="border-color: rgba(255,255,255,0.2);">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start small">
                    <p class="mb-0">&copy; 2025-2026 SWADIST - Authentic Mithila Snacks. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end small">
                    <p class="mb-0">
                        <i class="fas fa-heart text-danger"></i> 
                        Made with Love from Mithila 
                        <i class="fas fa-heart text-danger"></i>
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html>