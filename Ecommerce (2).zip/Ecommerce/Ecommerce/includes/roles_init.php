<?php
// Ensure 'role' column exists in users table and set default roles
if (!isset($conn)) {
    return;
}

$db = $conn->query("SELECT DATABASE() AS db")->fetch_assoc();
$schema = $db['db'];

$check = $conn->query("SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$schema' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role'");
if ($check) {
    $c = $check->fetch_assoc();
    if ($c['cnt'] == 0) {
        // Add role column with default 'user'
        $conn->query("ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'user'");
        // If there is a user with id=1 or email like 'admin', mark as admin
        $conn->query("UPDATE users SET role='admin' WHERE id=1 OR email='abc@gmail.com'");
    }
}

?>
